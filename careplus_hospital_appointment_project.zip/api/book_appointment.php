<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'POST method required.']);
    exit;
}

require_once __DIR__ . '/../config/db.php';

function failRequest(string $message, int $status = 422): never {
    http_response_code($status);
    echo json_encode(['success' => false, 'message' => $message]);
    exit;
}

$name = trim((string)($_POST['patient_name'] ?? ''));
$email = strtolower(trim((string)($_POST['email'] ?? '')));
$phone = trim((string)($_POST['phone'] ?? ''));
$doctorId = filter_var($_POST['doctor_id'] ?? null, FILTER_VALIDATE_INT);
$date = trim((string)($_POST['appointment_date'] ?? ''));
$time = trim((string)($_POST['appointment_time'] ?? ''));
$reason = trim((string)($_POST['reason'] ?? ''));

if (mb_strlen($name) < 2 || mb_strlen($name) > 100) failRequest('Enter a name between 2 and 100 characters.');
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) failRequest('Enter a valid email address.');
if (!preg_match('/^[0-9+() \-]{7,20}$/', $phone)) failRequest('Enter a valid phone number.');
if (!$doctorId || $doctorId < 1) failRequest('Choose a doctor.');
if (strlen($reason) > 1000) failRequest('Reason for visit is too long.');

$dateObj = DateTime::createFromFormat('!Y-m-d', $date);
if (!$dateObj || $dateObj->format('Y-m-d') !== $date || $date < date('Y-m-d')) failRequest('Choose a valid date today or in the future.');
$allowedTimes = ['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'];
if (!in_array($time, $allowedTimes, true)) failRequest('Choose an available time from the list.');

try {
    $pdo->beginTransaction();

    // Create or reuse a patient record by email. No password is collected in this demo.
    $findPatient = $pdo->prepare('SELECT id FROM patients WHERE email = ? LIMIT 1');
    $findPatient->execute([$email]);
    $patientId = $findPatient->fetchColumn();

    if ($patientId) {
        $updatePatient = $pdo->prepare('UPDATE patients SET full_name = ?, phone = ? WHERE id = ?');
        $updatePatient->execute([$name, $phone, $patientId]);
    } else {
        $insertPatient = $pdo->prepare('INSERT INTO patients (full_name, email, phone) VALUES (?, ?, ?)');
        $insertPatient->execute([$name, $email, $phone]);
        $patientId = (int)$pdo->lastInsertId();
    }

    $doctorCheck = $pdo->prepare('SELECT id FROM doctors WHERE id = ? AND active = 1');
    $doctorCheck->execute([$doctorId]);
    if (!$doctorCheck->fetch()) {
        $pdo->rollBack();
        failRequest('That doctor is not currently available. Please choose another.', 404);
    }

    // Prevent two active appointments for the same doctor, date and time.
    $slotCheck = $pdo->prepare("SELECT id FROM appointments WHERE doctor_id = ? AND appointment_date = ? AND appointment_time = ? AND status IN ('Pending','Confirmed') LIMIT 1 FOR UPDATE");
    $slotCheck->execute([$doctorId, $date, $time]);
    if ($slotCheck->fetch()) {
        $pdo->rollBack();
        failRequest('That time slot has just been booked. Please choose another time.', 409);
    }

    $insertAppointment = $pdo->prepare("INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, reason, status) VALUES (?, ?, ?, ?, ?, 'Pending')");
    $insertAppointment->execute([$patientId, $doctorId, $date, $time, $reason !== '' ? $reason : null]);
    $appointmentId = (int)$pdo->lastInsertId();
    $pdo->commit();

    echo json_encode(['success' => true, 'appointment_id' => $appointmentId, 'message' => 'Appointment request received.']);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log((string)$e);
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Something went wrong while booking. Please try again.']);
}
