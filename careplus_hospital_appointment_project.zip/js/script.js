const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
const doctorSearch = document.getElementById("doctorSearch");
const specialtyFilter = document.getElementById("specialtyFilter");
const doctorCards = [...document.querySelectorAll(".doctor-card")];
const doctorSelect = document.getElementById("doctorSelect");
const appointmentForm = document.getElementById("appointmentForm");
const formMessage = document.getElementById("formMessage");
const dateInput = document.getElementById("appointmentDate");

document.getElementById("year").textContent = new Date().getFullYear();

// This is a demo-only minimum date check. The server validates it again.
const today = new Date();
const localToday = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
dateInput.min = localToday;

menuToggle.addEventListener("click", () => mainNav.classList.toggle("open"));
mainNav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => mainNav.classList.remove("open")));

function filterDoctors() {
  const term = doctorSearch.value.trim().toLowerCase();
  const specialty = specialtyFilter.value;
  let shown = 0;
  doctorCards.forEach(card => {
    const matchesTerm = card.dataset.name.includes(term);
    const matchesSpecialty = !specialty || card.dataset.specialty === specialty;
    const visible = matchesTerm && matchesSpecialty;
    card.classList.toggle("hidden", !visible);
    if (visible) shown++;
  });
  document.getElementById("noDoctors").classList.toggle("hidden", shown !== 0);
}
doctorSearch.addEventListener("input", filterDoctors);
specialtyFilter.addEventListener("change", filterDoctors);

document.querySelectorAll(".choose-doctor").forEach(button => {
  button.addEventListener("click", () => {
    doctorSelect.value = button.dataset.id;
    document.getElementById("appointment").scrollIntoView({ behavior: "smooth" });
    doctorSelect.focus({ preventScroll: true });
  });
});

appointmentForm.addEventListener("submit", async event => {
  event.preventDefault();
  formMessage.className = "form-message";
  formMessage.textContent = "";

  if (dateInput.value < localToday) {
    formMessage.classList.add("error");
    formMessage.textContent = "Please choose today or a future date.";
    return;
  }

  const submitButton = appointmentForm.querySelector("button[type=submit]");
  submitButton.disabled = true;
  submitButton.textContent = "Submitting...";

  try {
    const response = await fetch("api/book_appointment.php", {
      method: "POST",
      body: new FormData(appointmentForm),
      headers: { "X-Requested-With": "XMLHttpRequest" }
    });
    const result = await response.json();
    if (!response.ok || !result.success) throw new Error(result.message || "Could not submit appointment.");
    formMessage.classList.add("success");
    formMessage.textContent = `Appointment request received. Your reference number is #${result.appointment_id}. Status: Pending confirmation.`;
    appointmentForm.reset();
    dateInput.min = localToday;
  } catch (error) {
    formMessage.classList.add("error");
    formMessage.textContent = error.message || "Unable to connect. Start the PHP server and try again.";
  } finally {
    submitButton.disabled = false;
    submitButton.innerHTML = 'Request appointment <span>→</span>';
  }
});
