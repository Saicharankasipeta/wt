CREATE DATABASE IF NOT EXISTS careplus_hospital
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE careplus_hospital;

CREATE TABLE IF NOT EXISTS hospitals (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  address VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  email VARCHAR(150),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS patients (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(20) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS doctors (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  hospital_id INT UNSIGNED NULL,
  full_name VARCHAR(120) NOT NULL,
  specialty VARCHAR(100) NOT NULL,
  experience_years TINYINT UNSIGNED NOT NULL DEFAULT 0,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_doctor_hospital FOREIGN KEY (hospital_id) REFERENCES hospitals(id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS appointments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  patient_id INT UNSIGNED NOT NULL,
  doctor_id INT UNSIGNED NOT NULL,
  appointment_date DATE NOT NULL,
  appointment_time TIME NOT NULL,
  reason VARCHAR(1000) NULL,
  status ENUM('Pending','Confirmed','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_appointment_patient FOREIGN KEY (patient_id) REFERENCES patients(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_appointment_doctor FOREIGN KEY (doctor_id) REFERENCES doctors(id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  INDEX idx_doctor_schedule (doctor_id, appointment_date, appointment_time, status),
  INDEX idx_patient_appointments (patient_id, appointment_date)
) ENGINE=InnoDB;

INSERT INTO hospitals (name, address, phone, email)
SELECT 'CarePlus Hospital', 'Hyderabad, Telangana, India', '+91 4000000000', 'contact@example.com'
WHERE NOT EXISTS (SELECT 1 FROM hospitals WHERE name = 'CarePlus Hospital');

SET @hospital_id = (SELECT id FROM hospitals WHERE name = 'CarePlus Hospital' LIMIT 1);

INSERT INTO doctors (hospital_id, full_name, specialty, experience_years)
SELECT @hospital_id, 'Dr. Ramesh Kumar', 'Cardiology', 12
WHERE NOT EXISTS (SELECT 1 FROM doctors WHERE full_name = 'Dr. Ramesh Kumar');
INSERT INTO doctors (hospital_id, full_name, specialty, experience_years)
SELECT @hospital_id, 'Dr. Priya Sharma', 'Dermatology', 8
WHERE NOT EXISTS (SELECT 1 FROM doctors WHERE full_name = 'Dr. Priya Sharma');
INSERT INTO doctors (hospital_id, full_name, specialty, experience_years)
SELECT @hospital_id, 'Dr. Arjun Mehta', 'Orthopedics', 10
WHERE NOT EXISTS (SELECT 1 FROM doctors WHERE full_name = 'Dr. Arjun Mehta');
INSERT INTO doctors (hospital_id, full_name, specialty, experience_years)
SELECT @hospital_id, 'Dr. Neha Verma', 'Pediatrics', 7
WHERE NOT EXISTS (SELECT 1 FROM doctors WHERE full_name = 'Dr. Neha Verma');
